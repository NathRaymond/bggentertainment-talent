<div class="container-fluid">
    <div class="row">
        <div class="col-sm-6">
            <script>
                document.write(new Date().getFullYear())
            </script> © BGG Entertainment.
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\YHHM Company\bgg-talent-app\resources\views/layouts/admin-layouts/admin-footer.blade.php ENDPATH**/ ?>